package Q1_StrategyDesignPattern;

public interface ValidationStrategy {
	boolean execute(String s);
}